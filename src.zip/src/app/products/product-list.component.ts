import { Component, OnInit } from '@angular/core';
import { IProduct } from './product';

@Component({
    selector: 'pm-products',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.css']
})

export class ProductListComponent implements OnInit{
   
    pageTitle: string="Product list";
    imageWidth: number= 50;
    imageMargin: number= 2;
    showImage : boolean=false; 
    _listFilter: string;
    filteredProducts: IProduct[];
    constructor(){
        this.filteredProducts=this.products;
        this.listFilter='cart';
    }
    get listFilter(): string {
         return this._listFilter; 
        }
    set listFilter(value:string) {
        this._listFilter = value;
        this.filteredProducts= this.listFilter ?
         this.performFilter(this.listFilter) : this.products; 
    }   
    performFilter(filterBy: string): IProduct[] {
        filterBy=filterBy.toLocaleLowerCase();
        return this.products.filter((product:IProduct) =>
         product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1);
    } 

    products:IProduct[]=[
        {
            "productId": 2,
             "productName": "Garden Cart",
             "productCode": "GDN-0023",
             "releaseDate": "March 18,2019",
             "price": 32.99,
             "description": "good capacity",
             "starRating": 4.2,
             "imageUrl": "assets/images/garden_cart.png"
           },{ 
            
            "productId": 5,
            "productName": "Hammer",
            "productCode": "GDN-0043",
            "releaseDate": "May 21,2019",
            "price":50.99,
            "description": "good steel",
            "starRating": 4.8,
            "imageUrl": "assets/images/hammer.png"
          }


    ];
    ngOnInit(): void {
        console.log("in onIt method");
    }
    toggleImage():void{
        this.showImage =!this.showImage;
    }

    
}